"use strict";
(function() {
  const URL = "https://api.nasa.gov/planetary/apod";
  const API_KEY = "jZhJk8NgFkGVMnhEnFZhEydDaGxtsEaeawjHQhwq"; // Replace with your NASA API key

  window.addEventListener("load", init);

  function init() {
    id("apod-btn").addEventListener("click", fetchAPOD);
  }

  async function fetchAPOD() {
    id("response-message").textContent = "Response Loading ...";
    id("response").innerHTML = "";
    id("apod-btn").disabled = true;

    let url = URL + "?api_key=" + API_KEY;

    let nameInput = id("name");
    let emailInput = id("email");
    let dayInput = id("day-input");
    let hdInput = id("hd");

    if (nameInput.value.trim() === "" || emailInput.value.trim() === "") {
      handleError("Please enter your name and email.");
      return;
    }

    url += "&date=" + dayInput.value;
    url += "&hd=" + hdInput.value;

    fetch(url)
      .then(statusCheck)
      .then((resp) => resp.json())
      .then(processApodJson)
      .catch(handleError);
  }

  function processApodJson(apodJson) {
    id("response-message").textContent = "Response";

    let title = gen("h2");
    title.textContent = apodJson.title;

    let image = gen("img");
    image.src = apodJson.url;
    image.alt = apodJson.title;

    let explanation = gen("p");
    explanation.textContent = apodJson.explanation;

    id("response").appendChild(title);
    id("response").appendChild(image);
    id("response").appendChild(explanation);

    if (apodJson.media_type === "video") {
      let video = gen("iframe");
      video.src = apodJson.url;
      video.width = "640";
      video.height = "360";
      id("response").appendChild(video);
    }

    let info = gen("div");
    info.textContent = "Requested by: " + id("name").value + " (" + id("email").value + ")";
    id("response").appendChild(info);

    id("apod-btn").disabled = false;
  }

  function handleError(err) {
    id("response-message").textContent = "Error";
    let error = gen("p");
    error.textContent = err;
    id("response").appendChild(error);
    id("apod-btn").disabled = false;
  }

  function id(idName) {
    return document.getElementById(idName);
  }

  function gen(tagName) {
    return document.createElement(tagName);
  }

  function statusCheck(response) {
    if (response.ok) {
      return response;
    }
    throw new Error("Error in request: " + response.statusText);
  }
})();
